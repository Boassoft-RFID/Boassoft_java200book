package kr.co.infopub.chapter.s113;
public class CardUtil {
	/**
	 * 4종류 Spade, Heart, Diamond, Clover
	 */
	public static String [] SUIT={"S","H","D","C"};
	/**
	 * 13가지 카드 값 1~10, J,Q,K
	 */
	public static String [] VALU={"A","2","3","4","5","6","7","8","9","T","J","Q","K"};
	
}//
