package kr.co.infopub.chapter.s185.dto;
import java.util.ArrayList;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
// DTO List -> Properties List for Screen -> List for JavaFX tree view or table view
public class DepConvert {
	// Convert the DTO to a properties object for the screen.
	public static Department toPro(DepartmentDto b){
		Department bp=new Department();
		bp.setDepartment_id(b.getDepartment_id());
		bp.setDepartment_name(b.getDepartment_name());
		bp.setLocation_id(b.getLocation_id());
		bp.setManager_id(b.getManager_id());
		return bp;
	}
	// Converts the DTO List to a property object list for the screen.
	public static List<Department> toPro(List<DepartmentDto> blist){
		List<Department> bplists=new ArrayList<>();
		for(DepartmentDto b:blist){
			bplists.add(toPro(b));
		}
		return bplists;
	}
	// Converts the list of properties objects for the screen to the List for JavaFX tree view or table view.
	public static ObservableList<Department> toObservPro(List<Department> alists){
		ObservableList<Department> bList = FXCollections.observableArrayList(alists);
		return bList;
	}
	// Converts a DTO List to a List for JavaFX tree view or table view.
	public static ObservableList<Department> toObservProFromDto(List<DepartmentDto> alists){
		return toObservPro(toPro(alists));
	}
}
