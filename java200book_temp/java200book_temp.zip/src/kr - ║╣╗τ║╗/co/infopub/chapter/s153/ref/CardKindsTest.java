package kr.co.infopub.chapter.s153.ref;

import kr.co.infopub.chapter.s153.ref.CardKinds;

public class CardKindsTest {

	public static void main(String[] args) {
		CardKinds kinds=new CardKinds();
		kinds.cardmake();
	}

}
