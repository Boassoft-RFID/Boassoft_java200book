package kr.co.infopub.chapter.s140;
public class TNailMain {
	public static void main(String[] args) {
		//시계 반대 방향
		TNail tnail=new TNail(7, 7);
		tnail.make();
		tnail.print();
	}
}
