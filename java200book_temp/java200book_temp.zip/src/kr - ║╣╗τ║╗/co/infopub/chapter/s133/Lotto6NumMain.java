package kr.co.infopub.chapter.s133;
public class Lotto6NumMain {
	public static void main(String[] args) {
		Lotto6Num lot=new Lotto6Num(45,6);
		lot.make();
		lot.print();
	}
}
