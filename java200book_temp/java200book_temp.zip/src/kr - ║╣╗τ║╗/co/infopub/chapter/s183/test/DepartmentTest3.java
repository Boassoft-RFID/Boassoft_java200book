package kr.co.infopub.chapter.s183.test;
import java.sql.SQLException;
import java.util.List;
import kr.co.infopub.chapter.s183.dto.DepCountDto;
import kr.co.infopub.chapter.s183.model.EmployeeDAO;
import kr.co.infopub.chapter.s183.util.EmpUtil;
public class DepartmentTest3 {
 public static void main(String[] args) {
	EmployeeDAO ddao=new EmployeeDAO();
	try {
		// a department with department members
		List<DepCountDto> dlists = ddao.findAllDepCounts();
		int total=0;
		for (DepCountDto dd: dlists) {
			total+=dd.getCount();
			System.out.print(EmpUtil.tname(dd));
			System.out.println("\t\t"+dd.getCount()+"(Person)");
		}
		System.out.println("----------comparison--------");
		System.out.println(total+"(Person)");
		
		int tot2=ddao.getEmployeesTotal();
		System.out.println(tot2+"(Person)");
	} catch (SQLException e) {
		System.out.println( e);
	}
 }
}
