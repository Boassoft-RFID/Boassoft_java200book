package kr.co.infopub.chapter.s119;
public class MagicPrint {
	public static void print(IMagicSquare magic){
		magic.make();
		magic.print();
	}
}
