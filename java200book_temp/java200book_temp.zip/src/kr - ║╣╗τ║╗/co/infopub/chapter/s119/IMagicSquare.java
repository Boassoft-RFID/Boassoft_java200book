package kr.co.infopub.chapter.s119;
// 100% 구현 안 된 메서드를 갖는 클래스 -> 인터페이스(추상 클래스임)
public interface IMagicSquare {
	void make();     // 반드시 구현해야 할 메서드
	void print();    // 반드시 구현해야 할 메서드
}
