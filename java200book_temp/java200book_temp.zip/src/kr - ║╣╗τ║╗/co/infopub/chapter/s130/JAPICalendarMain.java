package kr.co.infopub.chapter.s130;
public class JAPICalendarMain {
	public static void main(String[] args) {
		JAPICalendar haecal=new JAPICalendar();
		//haecal.showCal(2017, 2);
		haecal.showCal(2017);
	}
}
