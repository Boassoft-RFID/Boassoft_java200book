package kr.co.infopub.chapter.s015;
// 타입의 종류
public class JavaPrimaryType {
	public static void main(String[] args) {
		boolean isL=false;
		char suit='H';
		int year=2016;
		double latitude=37.52127220511242;
		double longitude=127.0074462890625;
		System.out.println(latitude+"\t"+longitude);
	}
}
