package kr.co.infopub.chapter.s033;
// 위도,경도를 저장하는 클래스
public class Geo {
	public double latitude;      
	public double longitude;   
}
