package kr.co.infopub.chapter.s150.swing;

public class TileUtil {
	public static final int TILESIZE=100;
}
