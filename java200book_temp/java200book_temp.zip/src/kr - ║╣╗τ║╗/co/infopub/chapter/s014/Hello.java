package kr.co.infopub.chapter.s014;
// 출력
public class Hello {
	public static void main(String[] args) {
		System.out.println("**********************************************");
		System.out.println("*        이 프로그래밍은 Java200이 만들었습니다.        *");
		System.out.println("**********************************************");
	}
}
