package kr.co.infopub.chapter.s122;
public class SilverStarMain2 {
	public static void main(String[] args) {
		 SilverStar.stepDown(7);
		 SilverStar.stepUp(7);
		 SilverStar.stepTri(7);
		 SilverStar.stepRevTri(7);
		 SilverStar.stepDia(15);
	}
}
