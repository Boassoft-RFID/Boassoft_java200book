package kr.co.infopub.chapter.s122;
public class SilverStarMain {
	public static void main(String[] args) {
		 SilverStar.stepDia(15);
	}
}
