package kr.co.infopub.chapter.s120;

public class MagicPrint {
	public static void print(IMagicSquare magic){
		magic.make();
		magic.print();
	}
}
