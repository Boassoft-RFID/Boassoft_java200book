package kr.co.infopub.chapter.s139;
public class SNailMain {
	public static void main(String[] args) {
		//시계 방향
		SNail snail=new SNail(7, 7);
		snail.make();
		snail.print();
	}
}
