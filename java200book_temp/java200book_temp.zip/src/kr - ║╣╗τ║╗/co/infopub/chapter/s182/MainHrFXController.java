package kr.co.infopub.chapter.s182;
import java.util.Date;
import java.util.Optional;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.BorderPane;
public class MainHrFXController {
 @FXML
 private MenuItem menuDepart;
 @FXML
 private MenuItem menuManage;
 @FXML
 private MenuItem menuSearch;
 @FXML
 private MenuItem menuUpdate;
 @FXML
 private MenuItem menuChart;
 @FXML
 private TabPane mainTabPane;
 @FXML
 private Tab tab3;
 @FXML
 private Tab tab1;
 @FXML
 private Tab tab2;
 @FXML
 private Tab tab4;
 @FXML
 private Tab tab5;
 @FXML
 private BorderPane searchTabBorder;
 @FXML
 private BorderPane empTabBorder;
 @FXML
 private BorderPane depChartBorder;
 @FXML
 private BorderPane debTabBorder;
 @FXML
 private BorderPane updateTabBorder;
 String systemver="HR Information Syste ver.0.2";
 @FXML
 void onStartAction(ActionEvent event) {
	  Alert alert = new Alert (Alert.AlertType.INFORMATION);
      alert.setTitle(systemver);
      alert.setHeaderText("HR Management System "+PTS.toDate3(new Date()));
      alert.setContentText(
    		  "HR Management System is a system for entering/editing information related to department management, administrator management, and personnel.");
      alert.show();
      mainTabPane.setVisible(true);    
 }
 @FXML
 void onExitAction(ActionEvent event) {
	Alert alert = new Alert(AlertType.CONFIRMATION);
	alert.setTitle(systemver);
    alert.setHeaderText("Do you want to exit HR Management System("+PTS.toDate3(new Date())+")?");
	alert.setContentText("Are you sure you want to finish it?");
	Optional<ButtonType> result = alert.showAndWait();
	if (result.get() == ButtonType.OK){
		Platform.exit();
		//System.exit(0);
	} else return;
 }
 @FXML
 void onHelpAction(ActionEvent event) {
	  Alert alert = new Alert (Alert.AlertType.INFORMATION);
      alert.setTitle(systemver);
      alert.setHeaderText("HR Management System "+PTS.toDate3(new Date()));
      alert.setContentText("Hello. This is "+systemver+". "
       + "\nHR Management System is a system for entering/editing information related to department management, administrator management, and personnel."
       + "\n Select the Start menu for Start.");
      alert.show();
 }
 @FXML
 void onMenuction(ActionEvent event) {
	// When you select a menu, the corresponding tab will appear.
 }
}
