package kr.co.infopub.chapter.s129;
public class JCalendarMain {
	public static void main(String[] args) {
		JCalendar cal=new JCalendar();
		//cal.showCal(2017, 2);
		cal.showCal(2017);
	}
}
