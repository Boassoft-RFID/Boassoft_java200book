package kr.co.infopub.chapter.s118;
public class MagicPrint {
	public static void print(MagicSquare magic){
		magic.make();
		magic.print();
	}
}
